import {
  ArrowRight,
  BookOpen,
  Check,
  ChevronDown,
  CircleHelp,
  Clock3,
  Copy,
  GraduationCap,
  Lightbulb,
  Menu,
  MessageCircle,
  NotebookPen,
  Pencil,
  PanelRightClose,
  PanelRightOpen,
  Plus,
  RotateCcw,
  Search,
  Send,
  Sparkles,
  Target,
  Trash2,
  X,
} from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { useLocation } from "wouter";
import type { Grade, SubjectKey, Unit } from "@/data/curriculum";
import {
  allUnits,
  getSubject,
  getUnit,
  subjectColors,
  subjects,
} from "@/data/curriculum";

const grades = [1, 2, 3] as const;

type GradeFilter = "all" | 1 | 2 | 3;
type SubjectFilter = "all" | SubjectKey;
type StudyPage =
  | "classroom"
  | "subjects"
  | "keywords"
  | "flashcards"
  | "practice"
  | "lesson";

const pageFromPath = (path: string): StudyPage => {
  if (path === "/subjects") return "subjects";
  if (path === "/keywords") return "keywords";
  if (path === "/flashcards") return "flashcards";
  if (path === "/practice") return "practice";
  if (path === "/lesson") return "lesson";
  return "classroom";
};

const parseGradeFilter = (value: string): GradeFilter =>
  value === "all" ? "all" : (Number(value) as 1 | 2 | 3);

function toggleSelection<T>(values: T[], value: T): T[] {
  return values.includes(value)
    ? values.filter(item => item !== value)
    : [...values, value];
}

function shuffleItems<T>(items: T[]): T[] {
  const shuffled = [...items];
  for (let index = shuffled.length - 1; index > 0; index -= 1) {
    const randomIndex = Math.floor(Math.random() * (index + 1));
    [shuffled[index], shuffled[randomIndex]] = [
      shuffled[randomIndex],
      shuffled[index],
    ];
  }
  return shuffled;
}

const normalizeWrittenAnswer = (value: string) =>
  value.trim().replace(/\s+/g, " ").toLowerCase();

type ChatMessage = {
  role: "user" | "assistant";
  content: string;
};

type DeckCard = {
  id: string;
  listId: string;
  subject: SubjectKey;
  publisher: string;
  years: Grade[];
  domains: string[];
  sortOrder: number;
  textbookPage: number | null;
  term: string;
  meaning: string;
  custom?: boolean;
};

type PracticeProblem = {
  id: string;
  listId: string;
  subject: SubjectKey;
  publisher: string;
  years: Grade[];
  domain: string;
  question: string;
  format?: "choice" | "written";
  choices: string[];
  answer: number;
  writtenAnswer?: string;
  explanation: string;
  custom?: boolean;
};

const KEYWORD_DECK_STORAGE_KEY = "manabiroom-keyword-deck-v1";
const PRACTICE_PROBLEMS_STORAGE_KEY = "manabiroom-practice-problems-v1";
const KEYWORD_LISTS_STORAGE_KEY = "manabiroom-keyword-lists-v1";
const PRACTICE_LISTS_STORAGE_KEY = "manabiroom-practice-lists-v1";
const DEFAULT_KEYWORD_LIST_ID = "keyword-list-default";
const DEFAULT_PRACTICE_LIST_ID = "practice-list-default";
const socialKeywordDomains = ["すべて", "地理", "歴史", "公民"] as const;

type StudyList = {
  id: string;
  name: string;
};

function sortDeckCards(cards: DeckCard[]): DeckCard[] {
  const subjectOrder = new Map(
    subjects.map((subject, index) => [subject.key, index])
  );
  return [...cards].sort(
    (a, b) =>
      (subjectOrder.get(a.subject) ?? 99) -
        (subjectOrder.get(b.subject) ?? 99) ||
      (a.textbookPage === null ? 1 : 0) - (b.textbookPage === null ? 1 : 0) ||
      (a.textbookPage ?? Number.MAX_SAFE_INTEGER) -
        (b.textbookPage ?? Number.MAX_SAFE_INTEGER) ||
      a.sortOrder - b.sortOrder ||
      a.term.localeCompare(b.term, "ja")
  );
}

function createDefaultDeck(): DeckCard[] {
  const cards = new Map<string, DeckCard>();
  const subjectUnitOrders = new Map<SubjectKey, number>();

  allUnits.forEach(unit => {
    const unitOrder = subjectUnitOrders.get(unit.subject) ?? 0;
    subjectUnitOrders.set(unit.subject, unitOrder + 1);
    unit.keywordCards.forEach(card => {
      const id = `${unit.subject}:${card.term}`;
      const existing = cards.get(id);
      if (existing) {
        existing.years = Array.from(
          new Set([...existing.years, ...unit.years])
        ).sort();
        existing.domains = Array.from(
          new Set([...existing.domains, unit.domain])
        );
        existing.sortOrder = Math.min(
          existing.sortOrder,
          unitOrder * 100 + unit.keywordCards.indexOf(card)
        );
        return;
      }

      cards.set(id, {
        id,
        listId: DEFAULT_KEYWORD_LIST_ID,
        subject: unit.subject,
        publisher: unit.publisher,
        years: [...unit.years],
        domains: [unit.domain],
        sortOrder: unitOrder * 100 + unit.keywordCards.indexOf(card),
        textbookPage: null,
        term: card.term,
        meaning: card.meaning,
      });
    });
  });

  return sortDeckCards(Array.from(cards.values()));
}

function loadKeywordDeck(): DeckCard[] {
  if (typeof window === "undefined") return createDefaultDeck();

  try {
    const saved = window.localStorage.getItem(KEYWORD_DECK_STORAGE_KEY);
    if (!saved) return createDefaultDeck();
    const parsed = JSON.parse(saved) as Partial<DeckCard>[];
    if (!Array.isArray(parsed)) return createDefaultDeck();
    const defaults = new Map(
      createDefaultDeck().map(card => [card.id, card.sortOrder])
    );
    return sortDeckCards(
      parsed
        .filter(
          card =>
            typeof card?.id === "string" &&
            typeof card?.subject === "string" &&
            typeof card?.term === "string" &&
            typeof card?.meaning === "string" &&
            Array.isArray(card?.years) &&
            Array.isArray(card?.domains)
        )
        .map((card, index) => ({
          ...(card as DeckCard),
          listId:
            typeof card.listId === "string"
              ? card.listId
              : DEFAULT_KEYWORD_LIST_ID,
          textbookPage:
            typeof card.textbookPage === "number" && card.textbookPage >= 0
              ? card.textbookPage
              : null,
          sortOrder:
            typeof card.sortOrder === "number"
              ? card.sortOrder
              : (defaults.get(card.id as string) ?? 100000 + index),
        }))
    );
  } catch {
    return createDefaultDeck();
  }
}

function createDefaultPracticeProblems(): PracticeProblem[] {
  return allUnits.map(unit => ({
    id: `unit-quiz:${unit.id}`,
    listId: DEFAULT_PRACTICE_LIST_ID,
    subject: unit.subject,
    publisher: unit.publisher,
    years: [...unit.years],
    domain: unit.domain,
    question: unit.quiz.question,
    choices: [...unit.quiz.choices],
    answer: unit.quiz.answer,
    explanation: unit.quiz.explanation,
  }));
}

function loadPracticeProblems(): PracticeProblem[] {
  if (typeof window === "undefined") return createDefaultPracticeProblems();

  try {
    const saved = window.localStorage.getItem(PRACTICE_PROBLEMS_STORAGE_KEY);
    if (!saved) return createDefaultPracticeProblems();
    const parsed = JSON.parse(saved) as Partial<PracticeProblem>[];
    if (!Array.isArray(parsed)) return createDefaultPracticeProblems();
    return parsed
      .filter(
        problem =>
          typeof problem?.id === "string" &&
          typeof problem?.subject === "string" &&
          Array.isArray(problem?.years) &&
          typeof problem?.domain === "string" &&
          typeof problem?.question === "string" &&
          Array.isArray(problem?.choices) &&
          problem.choices.length >= 2 &&
          problem.choices.every(choice => typeof choice === "string") &&
          typeof problem?.answer === "number" &&
          problem.answer >= 0 &&
          problem.answer < problem.choices.length &&
          typeof problem?.explanation === "string"
      )
      .map(problem => ({
        ...(problem as PracticeProblem),
        listId:
          typeof problem.listId === "string"
            ? problem.listId
            : DEFAULT_PRACTICE_LIST_ID,
      }));
  } catch {
    return createDefaultPracticeProblems();
  }
}

function loadStudyLists(
  storageKey: string,
  defaultId: string,
  defaultName: string
) {
  if (typeof window === "undefined")
    return [{ id: defaultId, name: defaultName }];
  try {
    const saved = window.localStorage.getItem(storageKey);
    if (!saved) return [{ id: defaultId, name: defaultName }];
    const parsed = JSON.parse(saved) as Partial<StudyList>[];
    const lists = parsed
      .filter(
        list => typeof list?.id === "string" && typeof list?.name === "string"
      )
      .map(list => ({ id: list.id as string, name: list.name!.trim() }))
      .filter(list => list.name);
    return lists.length > 0 ? lists : [{ id: defaultId, name: defaultName }];
  } catch {
    return [{ id: defaultId, name: defaultName }];
  }
}

const starterMessages: ChatMessage[] = [
  {
    role: "assistant",
    content:
      "こんにちは。いま開いている授業のことなら、どんな質問でも大丈夫です。『もっとかんたんに』『例を出して』も歓迎です。",
  },
];

function BookMark({ color = "#174F4B" }: { color?: string }) {
  return (
    <span
      className="book-mark"
      aria-hidden="true"
      style={{ background: color }}
    >
      <span />
      <span />
    </span>
  );
}

function SubjectIcon({
  subject,
  size = "normal",
}: {
  subject: (typeof subjects)[number];
  size?: "normal" | "large";
}) {
  return (
    <span
      className={`subject-icon subject-icon-${size}`}
      style={{
        background: `${subjectColors[subject.color]}18`,
        color: subjectColors[subject.color],
      }}
      aria-hidden="true"
    >
      {subject.icon}
    </span>
  );
}

function gradeLabel(unit: Unit) {
  return unit.years.length === 3 ? "中1〜3" : `中${unit.years[0]}`;
}

export default function Home() {
  const [location, navigate] = useLocation();
  const page = pageFromPath(location);
  const [grade, setGrade] = useState<GradeFilter>(1);
  const [subject, setSubject] = useState<SubjectFilter>("all");
  const [domain, setDomain] = useState("すべて");
  const [search, setSearch] = useState("");
  const [selectedUnitId, setSelectedUnitId] = useState("j1-kokugo");
  const [quizAnswer, setQuizAnswer] = useState<number | null>(null);
  const [aiOpen, setAiOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>(starterMessages);
  const [draft, setDraft] = useState("");
  const [aiLoading, setAiLoading] = useState(false);
  const [aiError, setAiError] = useState("");
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const [flippedKeywords, setFlippedKeywords] = useState<
    Record<string, boolean>
  >({});
  const [deckCards, setDeckCards] = useState<DeckCard[]>(loadKeywordDeck);
  const [keywordLists, setKeywordLists] = useState<StudyList[]>(() =>
    loadStudyLists(
      KEYWORD_LISTS_STORAGE_KEY,
      DEFAULT_KEYWORD_LIST_ID,
      "教科書キーワード"
    )
  );
  const [activeKeywordListId, setActiveKeywordListId] = useState(
    DEFAULT_KEYWORD_LIST_ID
  );
  const [copyTargetKeywordListId, setCopyTargetKeywordListId] = useState("");
  const [newKeywordListName, setNewKeywordListName] = useState("");
  const [deckSubject, setDeckSubject] = useState<SubjectFilter>("all");
  const [deckGrades, setDeckGrades] = useState<Grade[]>([]);
  const [deckSocialDomains, setDeckSocialDomains] = useState<string[]>([]);
  const [deckSearch, setDeckSearch] = useState("");
  const [flippedDeckCards, setFlippedDeckCards] = useState<
    Record<string, boolean>
  >({});
  const [editingDeckId, setEditingDeckId] = useState<string | null>(null);
  const [draftDeckTerm, setDraftDeckTerm] = useState("");
  const [draftDeckMeaning, setDraftDeckMeaning] = useState("");
  const [draftDeckSortOrder, setDraftDeckSortOrder] = useState("");
  const [draftDeckPage, setDraftDeckPage] = useState("");
  const [showDeckForm, setShowDeckForm] = useState(false);
  const [newDeckSubject, setNewDeckSubject] = useState<SubjectKey>("国語");
  const [newDeckGrades, setNewDeckGrades] = useState<Grade[]>([]);
  const [newDeckSocialDomains, setNewDeckSocialDomains] = useState<string[]>([
    "地理",
  ]);
  const [deckNotice, setDeckNotice] = useState("");
  const [flashSubject, setFlashSubject] = useState<SubjectFilter>("all");
  const [flashGrades, setFlashGrades] = useState<Grade[]>([]);
  const [flashSocialDomains, setFlashSocialDomains] = useState<string[]>([]);
  const [flashIndex, setFlashIndex] = useState(0);
  const [flashRevealed, setFlashRevealed] = useState(false);
  const [practiceProblems, setPracticeProblems] =
    useState<PracticeProblem[]>(loadPracticeProblems);
  const [practiceLists, setPracticeLists] = useState<StudyList[]>(() =>
    loadStudyLists(
      PRACTICE_LISTS_STORAGE_KEY,
      DEFAULT_PRACTICE_LIST_ID,
      "教科書確認問題"
    )
  );
  const [activePracticeListId, setActivePracticeListId] = useState(
    DEFAULT_PRACTICE_LIST_ID
  );
  const [newPracticeListName, setNewPracticeListName] = useState("");
  const [practiceSubject, setPracticeSubject] = useState<SubjectFilter>("all");
  const [practiceGrades, setPracticeGrades] = useState<Grade[]>([]);
  const [practiceSearch, setPracticeSearch] = useState("");
  const [practiceIndex, setPracticeIndex] = useState(0);
  const [practiceAnswer, setPracticeAnswer] = useState<number | string | null>(
    null
  );
  const [showPracticeForm, setShowPracticeForm] = useState(false);
  const [editingPracticeId, setEditingPracticeId] = useState<string | null>(
    null
  );
  const [draftPracticeQuestion, setDraftPracticeQuestion] = useState("");
  const [draftPracticeChoices, setDraftPracticeChoices] = useState<string[]>([
    "",
    "",
    "",
    "",
  ]);
  const [draftPracticeAnswer, setDraftPracticeAnswer] = useState("0");
  const [draftPracticeExplanation, setDraftPracticeExplanation] = useState("");
  const [draftPracticeFormat, setDraftPracticeFormat] = useState<
    "choice" | "written"
  >("choice");
  const [draftPracticeWrittenAnswer, setDraftPracticeWrittenAnswer] =
    useState("");
  const [practiceWrittenResponse, setPracticeWrittenResponse] = useState("");
  const [newPracticeSubject, setNewPracticeSubject] =
    useState<SubjectKey>("国語");
  const [newPracticeGrade, setNewPracticeGrade] = useState<GradeFilter>("all");
  const [practiceNotice, setPracticeNotice] = useState("");

  useEffect(() => {
    window.localStorage.setItem(
      KEYWORD_DECK_STORAGE_KEY,
      JSON.stringify(deckCards)
    );
  }, [deckCards]);

  useEffect(() => {
    window.localStorage.setItem(
      KEYWORD_LISTS_STORAGE_KEY,
      JSON.stringify(keywordLists)
    );
  }, [keywordLists]);

  useEffect(() => {
    const target = keywordLists.find(
      list =>
        list.id !== activeKeywordListId && list.id === copyTargetKeywordListId
    );
    if (!target) {
      setCopyTargetKeywordListId(
        keywordLists.find(list => list.id !== activeKeywordListId)?.id ?? ""
      );
    }
  }, [activeKeywordListId, copyTargetKeywordListId, keywordLists]);

  useEffect(() => {
    window.localStorage.setItem(
      PRACTICE_PROBLEMS_STORAGE_KEY,
      JSON.stringify(practiceProblems)
    );
  }, [practiceProblems]);

  useEffect(() => {
    window.localStorage.setItem(
      PRACTICE_LISTS_STORAGE_KEY,
      JSON.stringify(practiceLists)
    );
  }, [practiceLists]);

  const filteredUnits = useMemo(() => {
    const query = search.trim().toLowerCase();
    return allUnits.filter(unit => {
      const matchesGrade = grade === "all" || unit.years.includes(grade);
      const matchesSubject = subject === "all" || unit.subject === subject;
      const matchesDomain = domain === "すべて" || unit.domain === domain;
      const matchesSearch =
        !query ||
        [unit.title, unit.subject, unit.domain, unit.summary, ...unit.terms]
          .join(" ")
          .toLowerCase()
          .includes(query);
      return matchesGrade && matchesSubject && matchesDomain && matchesSearch;
    });
  }, [grade, subject, domain, search]);

  const domains = useMemo(() => {
    const source =
      subject === "all"
        ? allUnits
        : allUnits.filter(unit => unit.subject === subject);
    return ["すべて", ...Array.from(new Set(source.map(unit => unit.domain)))];
  }, [subject]);

  const currentUnit = getUnit(selectedUnitId);
  const currentSubject = getSubject(currentUnit.subject);
  const recommendedUnit = filteredUnits[0] ?? allUnits[0];

  const filteredDeckCards = useMemo(() => {
    const query = deckSearch.trim().toLowerCase();
    return sortDeckCards(
      deckCards.filter(card => {
        if (card.listId !== activeKeywordListId) return false;
        const matchesSubject =
          deckSubject === "all" || card.subject === deckSubject;
        const matchesGrade =
          deckGrades.length === 0 ||
          deckGrades.some(selectedGrade => card.years.includes(selectedGrade));
        const matchesSocialDomain =
          deckSubject !== "社会" ||
          deckSocialDomains.length === 0 ||
          deckSocialDomains.some(selectedDomain =>
            card.domains.includes(selectedDomain)
          );
        const matchesSearch =
          !query ||
          [
            card.term,
            card.meaning,
            card.subject,
            card.publisher,
            ...card.domains,
          ]
            .join(" ")
            .toLowerCase()
            .includes(query);
        return (
          matchesSubject && matchesGrade && matchesSocialDomain && matchesSearch
        );
      })
    );
  }, [
    activeKeywordListId,
    deckCards,
    deckGrades,
    deckSearch,
    deckSocialDomains,
    deckSubject,
  ]);

  const flashCards = useMemo(
    () =>
      sortDeckCards(
        deckCards.filter(card => {
          if (card.listId !== activeKeywordListId) return false;
          const matchesSubject =
            flashSubject === "all" || card.subject === flashSubject;
          const matchesGrade =
            flashGrades.length === 0 ||
            flashGrades.some(selectedGrade =>
              card.years.includes(selectedGrade)
            );
          const matchesSocialDomain =
            flashSubject !== "社会" ||
            flashSocialDomains.length === 0 ||
            flashSocialDomains.some(selectedDomain =>
              card.domains.includes(selectedDomain)
            );
          return matchesSubject && matchesGrade && matchesSocialDomain;
        })
      ),
    [
      activeKeywordListId,
      deckCards,
      flashGrades,
      flashSocialDomains,
      flashSubject,
    ]
  );

  const randomizedFlashCards = useMemo(
    () => shuffleItems(flashCards),
    [flashCards]
  );
  const currentFlashCard = randomizedFlashCards[flashIndex] ?? null;

  const filteredPracticeProblems = useMemo(() => {
    const query = practiceSearch.trim().toLowerCase();
    return practiceProblems.filter(problem => {
      if (problem.listId !== activePracticeListId) return false;
      const matchesSubject =
        practiceSubject === "all" || problem.subject === practiceSubject;
      const matchesGrade =
        practiceGrades.length === 0 ||
        practiceGrades.some(selectedGrade =>
          problem.years.includes(selectedGrade)
        );
      const matchesSearch =
        !query ||
        [
          problem.question,
          problem.explanation,
          problem.subject,
          problem.domain,
          ...problem.choices,
        ]
          .join(" ")
          .toLowerCase()
          .includes(query);
      return matchesSubject && matchesGrade && matchesSearch;
    });
  }, [
    activePracticeListId,
    practiceGrades,
    practiceProblems,
    practiceSearch,
    practiceSubject,
  ]);

  const randomizedPracticeProblems = useMemo(
    () => shuffleItems(filteredPracticeProblems),
    [filteredPracticeProblems]
  );

  const currentPracticeProblem =
    randomizedPracticeProblems[practiceIndex] ?? null;
  const currentPracticeIsWritten = currentPracticeProblem?.format === "written";
  const currentWrittenAnswerIsCorrect =
    currentPracticeIsWritten &&
    typeof practiceAnswer === "string" &&
    normalizeWrittenAnswer(practiceAnswer) ===
      normalizeWrittenAnswer(currentPracticeProblem?.writtenAnswer ?? "");

  useEffect(() => {
    setFlashIndex(0);
    setFlashRevealed(false);
  }, [activeKeywordListId, flashGrades, flashSocialDomains, flashSubject]);

  useEffect(() => {
    if (flashCards.length > 0 && flashIndex >= flashCards.length) {
      setFlashIndex(0);
      setFlashRevealed(false);
    }
  }, [flashCards.length, flashIndex]);

  useEffect(() => {
    setPracticeIndex(0);
    setPracticeAnswer(null);
    setPracticeWrittenResponse("");
  }, [activePracticeListId, practiceGrades, practiceSearch, practiceSubject]);

  useEffect(() => {
    if (
      filteredPracticeProblems.length > 0 &&
      practiceIndex >= filteredPracticeProblems.length
    ) {
      setPracticeIndex(0);
      setPracticeAnswer(null);
      setPracticeWrittenResponse("");
    }
  }, [filteredPracticeProblems.length, practiceIndex]);

  const selectSubject = (nextSubject: SubjectFilter) => {
    setSubject(nextSubject);
    setDomain("すべて");
    const nextUnit = allUnits.find(unit =>
      nextSubject === "all"
        ? unit.years.includes(grade === "all" ? 1 : grade)
        : unit.subject === nextSubject &&
          unit.years.includes(grade === "all" ? 1 : grade)
    );
    if (nextUnit) {
      setSelectedUnitId(nextUnit.id);
      setQuizAnswer(null);
      setFlippedKeywords({});
    }
    setMobileNavOpen(false);
  };

  const selectGrade = (nextGrade: GradeFilter) => {
    setGrade(nextGrade);
    const nextUnit = allUnits.find(
      unit =>
        (nextGrade === "all" || unit.years.includes(nextGrade)) &&
        (subject === "all" || unit.subject === subject)
    );
    if (nextUnit) {
      setSelectedUnitId(nextUnit.id);
      setQuizAnswer(null);
      setFlippedKeywords({});
    }
  };

  const selectUnit = (unit: Unit) => {
    setSelectedUnitId(unit.id);
    setQuizAnswer(null);
    setFlippedKeywords({});
    navigate("/lesson");
  };

  const createKeywordList = () => {
    const name = newKeywordListName.trim();
    if (!name) return;
    const list = { id: `keyword-list-${Date.now()}`, name };
    setKeywordLists(prev => [...prev, list]);
    setActiveKeywordListId(list.id);
    setCopyTargetKeywordListId("");
    setNewKeywordListName("");
    setDeckNotice(`「${name}」を作成しました。`);
  };

  const createPracticeList = () => {
    const name = newPracticeListName.trim();
    if (!name) return;
    const list = { id: `practice-list-${Date.now()}`, name };
    setPracticeLists(prev => [...prev, list]);
    setActivePracticeListId(list.id);
    setNewPracticeListName("");
    setPracticeNotice(`「${name}」を作成しました。`);
  };

  const copyKeywordToList = (cardId: string) => {
    if (
      !copyTargetKeywordListId ||
      copyTargetKeywordListId === activeKeywordListId
    ) {
      setDeckNotice("先にコピー先のリストを選んでください。");
      return;
    }
    const source = deckCards.find(card => card.id === cardId);
    if (!source) return;
    const nextSortOrder =
      Math.max(
        0,
        ...deckCards
          .filter(
            card =>
              card.listId === copyTargetKeywordListId &&
              card.subject === source.subject
          )
          .map(card => card.sortOrder)
      ) + 100;
    const copiedCard: DeckCard = {
      ...source,
      id: `${source.id}:copy:${Date.now()}`,
      listId: copyTargetKeywordListId,
      sortOrder: nextSortOrder,
      custom: true,
    };
    setDeckCards(prev => [...prev, copiedCard]);
    const targetName = keywordLists.find(
      list => list.id === copyTargetKeywordListId
    )?.name;
    setDeckNotice(
      `「${source.term}」を「${targetName ?? "別のリスト"}」へコピーしました。`
    );
  };

  const beginDeckEdit = (card: DeckCard) => {
    setEditingDeckId(card.id);
    setDraftDeckTerm(card.term);
    setDraftDeckMeaning(card.meaning);
    setDraftDeckSortOrder(String(card.sortOrder));
    setDraftDeckPage(
      card.textbookPage === null ? "" : String(card.textbookPage)
    );
    setDeckNotice("");
  };

  const cancelDeckEdit = () => {
    setEditingDeckId(null);
    setDraftDeckTerm("");
    setDraftDeckMeaning("");
    setDraftDeckSortOrder("");
    setDraftDeckPage("");
  };

  const saveDeckEdit = (cardId: string) => {
    const term = draftDeckTerm.trim();
    const meaning = draftDeckMeaning.trim();
    const sortOrder = Number(draftDeckSortOrder);
    const textbookPage =
      draftDeckPage.trim() === "" ? null : Number(draftDeckPage);
    if (
      !term ||
      !meaning ||
      !Number.isInteger(sortOrder) ||
      (textbookPage !== null &&
        (!Number.isInteger(textbookPage) || textbookPage < 0))
    ) {
      setDeckNotice("キーワード・意味・並び順・ページ番号を確認してください。");
      return;
    }

    setDeckCards(prev =>
      sortDeckCards(
        prev.map(card =>
          card.id === cardId
            ? { ...card, term, meaning, sortOrder, textbookPage }
            : card
        )
      )
    );
    cancelDeckEdit();
    setDeckNotice("カードを更新しました。");
  };

  const addDeckCard = () => {
    const term = draftDeckTerm.trim();
    const meaning = draftDeckMeaning.trim();
    if (!term || !meaning) {
      setDeckNotice("キーワードと意味の両方を入力してください。");
      return;
    }
    if (newDeckSubject === "社会" && newDeckSocialDomains.length === 0) {
      setDeckNotice("社会の分野を1つ以上選択してください。");
      return;
    }

    const years: Grade[] =
      newDeckGrades.length === 0 ? [1, 2, 3] : newDeckGrades;
    const subjectInfo = getSubject(newDeckSubject);
    const textbookPage =
      draftDeckPage.trim() === "" ? null : Number(draftDeckPage);
    if (
      textbookPage !== null &&
      (!Number.isInteger(textbookPage) || textbookPage < 0)
    ) {
      setDeckNotice("教科書ページは0以上の数字で入力してください。");
      return;
    }
    const nextSortOrder =
      Math.max(
        0,
        ...deckCards
          .filter(
            card =>
              card.listId === activeKeywordListId &&
              card.subject === newDeckSubject
          )
          .map(card => card.sortOrder)
      ) + 100;
    const newCard: DeckCard = {
      id: `custom-${Date.now()}`,
      listId: activeKeywordListId,
      subject: newDeckSubject,
      publisher: subjectInfo.publisher,
      years,
      domains:
        newDeckSubject === "社会" ? newDeckSocialDomains : ["自分のカード"],
      sortOrder: nextSortOrder,
      textbookPage,
      term,
      meaning,
      custom: true,
    };
    setDeckCards(prev => sortDeckCards([newCard, ...prev]));
    setDraftDeckTerm("");
    setDraftDeckMeaning("");
    setDraftDeckPage("");
    setShowDeckForm(true);
    setDeckNotice("自分のカードを追加しました。続けて何枚でも作成できます。");
  };

  const deleteDeckCard = (cardId: string) => {
    setDeckCards(prev => prev.filter(card => card.id !== cardId));
    setFlippedDeckCards(prev => {
      const next = { ...prev };
      delete next[cardId];
      return next;
    });
    setDeckNotice("カードを削除しました。");
  };

  const resetDeck = () => {
    if (
      !window.confirm("編集したカードと追加したカードを初期状態に戻しますか？")
    ) {
      return;
    }
    setDeckCards(prev => [
      ...prev.filter(card => card.listId !== activeKeywordListId),
      ...(activeKeywordListId === DEFAULT_KEYWORD_LIST_ID
        ? createDefaultDeck()
        : []),
    ]);
    setFlippedDeckCards({});
    cancelDeckEdit();
    setShowDeckForm(false);
    setDeckNotice("教科書キーワードを初期状態に戻しました。");
  };

  const beginPracticeEdit = (problem: PracticeProblem) => {
    setShowPracticeForm(true);
    setEditingPracticeId(problem.id);
    setDraftPracticeQuestion(problem.question);
    setDraftPracticeFormat(problem.format === "written" ? "written" : "choice");
    setDraftPracticeChoices([...problem.choices]);
    setDraftPracticeAnswer(String(problem.answer));
    setDraftPracticeWrittenAnswer(problem.writtenAnswer ?? "");
    setDraftPracticeExplanation(problem.explanation);
    setPracticeNotice("");
  };

  const cancelPracticeEdit = () => {
    setEditingPracticeId(null);
    setDraftPracticeQuestion("");
    setDraftPracticeFormat("choice");
    setDraftPracticeChoices(["", "", "", ""]);
    setDraftPracticeAnswer("0");
    setDraftPracticeWrittenAnswer("");
    setDraftPracticeExplanation("");
  };

  const validatePracticeDraft = () => {
    const question = draftPracticeQuestion.trim();
    const explanation = draftPracticeExplanation.trim();
    if (draftPracticeFormat === "written") {
      const writtenAnswer = draftPracticeWrittenAnswer.trim();
      if (!question || !writtenAnswer || !explanation) {
        setPracticeNotice("問題文・模範解答・解説をすべて入力してください。");
        return null;
      }
      return {
        question,
        format: "written" as const,
        choices: [],
        answer: -1,
        writtenAnswer,
        explanation,
      };
    }
    const choices = draftPracticeChoices.map(choice => choice.trim());
    const answer = Number(draftPracticeAnswer);
    if (
      !question ||
      choices.length < 2 ||
      choices.some(choice => !choice) ||
      !Number.isInteger(answer) ||
      answer < 0 ||
      answer >= choices.length ||
      !explanation
    ) {
      setPracticeNotice(
        "問題・選択肢4つ・正解・解説をすべて入力してください。"
      );
      return null;
    }
    return {
      question,
      format: "choice" as const,
      choices,
      answer,
      explanation,
    };
  };

  const savePracticeEdit = (problemId: string) => {
    const draft = validatePracticeDraft();
    if (!draft) return;
    setPracticeProblems(prev =>
      prev.map(problem =>
        problem.id === problemId ? { ...problem, ...draft } : problem
      )
    );
    cancelPracticeEdit();
    setPracticeAnswer(null);
    setPracticeWrittenResponse("");
    setPracticeNotice("練習問題を更新しました。");
  };

  const addPracticeProblem = () => {
    const draft = validatePracticeDraft();
    if (!draft) return;
    const subjectInfo = getSubject(newPracticeSubject);
    const newProblem: PracticeProblem = {
      id: `custom-practice-${Date.now()}`,
      listId: activePracticeListId,
      subject: newPracticeSubject,
      publisher: subjectInfo.publisher,
      years: newPracticeGrade === "all" ? [1, 2, 3] : [newPracticeGrade],
      domain: "自作問題",
      ...draft,
      custom: true,
    };
    setPracticeProblems(prev => [newProblem, ...prev]);
    cancelPracticeEdit();
    setPracticeWrittenResponse("");
    setShowPracticeForm(true);
    setPracticeNotice("練習問題を追加しました。続けて何問でも作成できます。");
  };

  const deletePracticeProblem = (problemId: string) => {
    setPracticeProblems(prev =>
      prev.filter(problem => problem.id !== problemId)
    );
    setPracticeAnswer(null);
    setPracticeNotice("練習問題を削除しました。");
  };

  const resetPracticeProblems = () => {
    if (!window.confirm("自作・編集した問題を初期状態に戻しますか？")) return;
    setPracticeProblems(prev => [
      ...prev.filter(problem => problem.listId !== activePracticeListId),
      ...(activePracticeListId === DEFAULT_PRACTICE_LIST_ID
        ? createDefaultPracticeProblems()
        : []),
    ]);
    cancelPracticeEdit();
    setShowPracticeForm(false);
    setPracticeNotice("練習問題を初期状態に戻しました。");
  };

  const sendQuestion = async (question?: string) => {
    const content = (question ?? draft).trim();
    if (!content || aiLoading) return;
    setAiError("");
    setDraft("");
    const nextMessages = [...messages, { role: "user" as const, content }];
    setMessages(nextMessages);
    setAiLoading(true);
    try {
      const response = await fetch("/api/ai/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          context: {
            subject: currentUnit.subject,
            publisher: currentUnit.publisher,
            grade: gradeLabel(currentUnit),
            domain: currentUnit.domain,
            unit: currentUnit.title,
            summary: currentUnit.summary,
            points: currentUnit.points,
            terms: currentUnit.terms,
          },
          messages: nextMessages,
        }),
      });
      const payload = await response.json();
      if (!response.ok)
        throw new Error(payload.error || "AI先生が一時的に休憩中です。");
      setMessages(prev => [
        ...prev,
        { role: "assistant", content: payload.content },
      ]);
    } catch (error) {
      setDraft(content);
      setAiError(
        error instanceof Error
          ? error.message
          : "AI先生に接続できませんでした。"
      );
    } finally {
      setAiLoading(false);
    }
  };

  return (
    <div className="school-app">
      <header className="topbar">
        <a className="brand" href="/" aria-label="まなび教室 ホーム">
          <BookMark />
          <span>
            <strong>まなび教室</strong>
            <small>中学生の放課後学習室</small>
          </span>
        </a>
        <nav
          className={`main-nav ${mobileNavOpen ? "is-open" : ""}`}
          aria-label="メインナビゲーション"
        >
          <a className={page === "classroom" ? "active" : ""} href="/">
            教室
          </a>
          <a className={page === "subjects" ? "active" : ""} href="/subjects">
            教科の棚
          </a>
          <a className={page === "keywords" ? "active" : ""} href="/keywords">
            キーワード帳
          </a>
          <a
            className={page === "flashcards" ? "active" : ""}
            href="/flashcards"
          >
            スラッシュカード
          </a>
          <a className={page === "practice" ? "active" : ""} href="/practice">
            練習問題
          </a>
          <a className={page === "lesson" ? "active" : ""} href="/lesson">
            授業ノート
          </a>
          <button
            className="nav-ai"
            type="button"
            onClick={() => setAiOpen(true)}
          >
            <Sparkles size={15} /> AI先生
          </button>
        </nav>
        <div className="topbar-actions">
          <span className="streak">
            <span className="streak-dot" /> 今日は 1日目
          </span>
          <button
            className="mobile-menu"
            type="button"
            onClick={() => setMobileNavOpen(open => !open)}
            aria-label="メニュー"
          >
            <Menu size={20} />
          </button>
        </div>
      </header>

      <main id="top">
        {page === "classroom" && (
          <section id="classroom" className="classroom-hero page-shell">
            <div className="hero-board">
              <div className="board-topline">
                <span>今日のホームルーム</span>
                <span>MON / 10.21</span>
              </div>
              <div className="board-content">
                <p className="chalk-kicker">AFTER SCHOOL STUDY ROOM</p>
                <h1>
                  今日の一歩を、
                  <br />
                  <em>黒板</em>から。
                </h1>
                <p className="hero-copy">
                  教科書に沿って、わからないを
                  <br className="desktop-only" />
                  「わかった」に変えていこう。
                </p>
                <div className="hero-actions">
                  <button
                    className="primary-button"
                    type="button"
                    onClick={() => selectUnit(recommendedUnit)}
                  >
                    授業をはじめる <ArrowRight size={16} />
                  </button>
                  <span className="hero-note">
                    <NotebookPen size={14} /> 8教科 / 3学年
                  </span>
                </div>
              </div>
              <div className="board-doodle doodle-sun" aria-hidden="true" />
              <div className="board-doodle doodle-star" aria-hidden="true">
                ✦
              </div>
              <div className="board-shelf" aria-hidden="true">
                <span />
                <span />
                <span />
                <span />
              </div>
            </div>
            <div className="hero-side">
              <div className="notice-card paper-card">
                <span className="pin pin-coral" />
                <p className="eyebrow">TODAY'S NOTE</p>
                <h2>
                  まずは、
                  <br />
                  <span>15分だけ。</span>
                </h2>
                <p>短い授業をひとつ選ぶと、勉強のスイッチが入ります。</p>
                <a className="text-button" href="/subjects">
                  教科の棚を見る <ArrowRight size={14} />
                </a>
              </div>
              <div className="mini-card paper-card">
                <div className="mini-card-icon">
                  <Target size={18} />
                </div>
                <div>
                  <strong>学習の進み具合</strong>
                  <span>今週は 2 / 5コマ</span>
                </div>
                <div className="progress-ring">
                  <b>40</b>
                  <small>%</small>
                </div>
              </div>
            </div>
          </section>
        )}

        {page === "subjects" && (
          <section className="desk-layout page-shell" id="subjects">
            <aside className="left-desk">
              <div className="desk-label">
                <span className="wood-dot" /> MY DESK
              </div>
              <div className="grade-panel paper-card">
                <div className="panel-heading">
                  <span>学年を選ぶ</span>
                  <GraduationCap size={18} />
                </div>
                <div className="grade-tabs" role="tablist" aria-label="学年">
                  <button
                    className={grade === "all" ? "selected" : ""}
                    onClick={() => selectGrade("all")}
                    type="button"
                  >
                    全部
                  </button>
                  {grades.map(value => (
                    <button
                      className={grade === value ? "selected" : ""}
                      onClick={() => selectGrade(value)}
                      type="button"
                      key={value}
                    >
                      中学{value}年
                    </button>
                  ))}
                </div>
              </div>
              <div className="tip-card">
                <Lightbulb size={17} />
                <div>
                  <strong>勉強のコツ</strong>
                  <p>わからない言葉は、まず声に出して読んでみよう。</p>
                </div>
              </div>
            </aside>

            <div className="shelf-area">
              <div className="section-heading">
                <div>
                  <p className="eyebrow">TEXTBOOK SHELF</p>
                  <h2>教科の棚</h2>
                </div>
                <span className="unit-count">{filteredUnits.length} 授業</span>
              </div>
              <div
                className="subject-scroller"
                role="tablist"
                aria-label="教科"
              >
                <button
                  className={`subject-pill all-pill ${subject === "all" ? "selected" : ""}`}
                  onClick={() => selectSubject("all")}
                  type="button"
                >
                  <span className="all-subject-icon">すべて</span>
                  <span>全教科</span>
                </button>
                {subjects.map(item => (
                  <button
                    key={item.key}
                    className={`subject-pill ${subject === item.key ? "selected" : ""}`}
                    onClick={() => selectSubject(item.key)}
                    type="button"
                  >
                    <SubjectIcon subject={item} />
                    <span>{item.key}</span>
                  </button>
                ))}
              </div>
              <div className="filter-row">
                <div className="domain-select-wrap">
                  <span>分野</span>
                  <select
                    value={domain}
                    onChange={event => setDomain(event.target.value)}
                    aria-label="分野で絞り込む"
                  >
                    {domains.map(item => (
                      <option key={item}>{item}</option>
                    ))}
                  </select>
                  <ChevronDown size={14} />
                </div>
                <label className="search-box">
                  <Search size={16} />
                  <input
                    value={search}
                    onChange={event => setSearch(event.target.value)}
                    placeholder="単元を検索"
                    aria-label="単元を検索"
                  />
                </label>
              </div>
              <div className="unit-grid">
                {filteredUnits.slice(0, 12).map(unit => {
                  const item = getSubject(unit.subject);
                  return (
                    <button
                      key={unit.id}
                      className={`unit-card paper-card ${currentUnit.id === unit.id ? "selected" : ""}`}
                      onClick={() => selectUnit(unit)}
                      type="button"
                    >
                      <div className="unit-card-top">
                        <SubjectIcon subject={item} size="large" />
                        <span className="unit-grade">{gradeLabel(unit)}</span>
                      </div>
                      <p>{unit.eyebrow}</p>
                      <h3>{unit.title}</h3>
                      <span className="unit-summary">{unit.summary}</span>
                      <span className="unit-card-footer">
                        <span style={{ color: subjectColors[item.color] }}>
                          {unit.subject} / {unit.domain}
                        </span>
                        <ArrowRight size={15} />
                      </span>
                    </button>
                  );
                })}
                {filteredUnits.length === 0 && (
                  <div className="empty-state paper-card">
                    <Search size={22} />
                    <strong>授業が見つかりませんでした</strong>
                    <span>学年や検索語を変えてみてください。</span>
                  </div>
                )}
              </div>
              {filteredUnits.length > 12 && (
                <p className="shelf-more">
                  表示中 12 / {filteredUnits.length} 授業　
                  <span>検索や分野でさらに絞り込めます</span>
                </p>
              )}
            </div>
          </section>
        )}

        {page === "keywords" && (
          <section
            id="keyword-deck"
            className="keyword-deck-section page-shell"
          >
            <div className="keyword-deck-heading">
              <div>
                <p className="eyebrow">MY KEYWORD DECK</p>
                <h2>教科別キーワード帳</h2>
                <p>
                  8教科の重要語句をまとめました。カードをめくって意味を確認し、
                  教科書ページの小さい順に並べます。ページ未入力のカードは後ろに表示します。
                  自分の言葉と並び順も編集でき、
                  自分のカードは何枚でも追加できます。
                </p>
              </div>
              <div className="keyword-deck-actions">
                <button
                  className="deck-add-button"
                  type="button"
                  onClick={() => {
                    setShowDeckForm(open => !open);
                    setEditingDeckId(null);
                    setDeckNotice("");
                  }}
                >
                  <Plus size={16} /> 自分のカードを追加
                </button>
                <button
                  className="deck-reset-button"
                  type="button"
                  onClick={resetDeck}
                >
                  <RotateCcw size={14} /> 初期状態に戻す
                </button>
              </div>
            </div>

            <div className="study-list-manager">
              <label>
                キーワードリスト
                <select
                  value={activeKeywordListId}
                  onChange={event => {
                    setActiveKeywordListId(event.target.value);
                    setEditingDeckId(null);
                    setFlippedDeckCards({});
                  }}
                >
                  {keywordLists.map(list => (
                    <option value={list.id} key={list.id}>
                      {list.name}
                    </option>
                  ))}
                </select>
              </label>
              <form
                className="study-list-create"
                onSubmit={event => {
                  event.preventDefault();
                  createKeywordList();
                }}
              >
                <input
                  value={newKeywordListName}
                  onChange={event => setNewKeywordListName(event.target.value)}
                  placeholder="新しいリスト名"
                  aria-label="新しいキーワードリスト名"
                />
                <button type="submit">
                  <Plus size={14} /> リストを作る
                </button>
              </form>
              <span className="study-list-count">
                {keywordLists.length}個のリスト
              </span>
            </div>
            <div className="keyword-copy-tools">
              <Copy size={14} />
              <span>教科書キーワードをコピー：</span>
              <select
                value={copyTargetKeywordListId}
                onChange={event =>
                  setCopyTargetKeywordListId(event.target.value)
                }
                disabled={keywordLists.length < 2}
                aria-label="キーワードのコピー先リスト"
              >
                <option value="">
                  {keywordLists.length < 2
                    ? "先に別のリストを作成してください"
                    : "コピー先を選択"}
                </option>
                {keywordLists
                  .filter(list => list.id !== activeKeywordListId)
                  .map(list => (
                    <option value={list.id} key={list.id}>
                      {list.name}
                    </option>
                  ))}
              </select>
              <small>各カードのコピーアイコンから追加できます</small>
            </div>

            <div className="keyword-deck-toolbar">
              <div
                className="deck-subject-filter"
                aria-label="キーワード帳の教科"
              >
                <button
                  className={deckSubject === "all" ? "selected" : ""}
                  type="button"
                  onClick={() => {
                    setDeckSubject("all");
                    setDeckSocialDomains([]);
                  }}
                >
                  全教科
                </button>
                {subjects.map(item => (
                  <button
                    key={item.key}
                    className={deckSubject === item.key ? "selected" : ""}
                    type="button"
                    onClick={() => {
                      setDeckSubject(item.key);
                      setDeckSocialDomains([]);
                    }}
                  >
                    <span style={{ color: subjectColors[item.color] }}>
                      {item.icon}
                    </span>
                    {item.key}
                  </button>
                ))}
              </div>
              {deckSubject === "社会" && (
                <div className="social-domain-filter" aria-label="社会の分野">
                  <span>社会の分野</span>
                  {socialKeywordDomains.map(item => (
                    <button
                      className={
                        deckSocialDomains.length === 0 ||
                        deckSocialDomains.includes(item)
                          ? "selected"
                          : ""
                      }
                      key={item}
                      type="button"
                      onClick={() =>
                        setDeckSocialDomains(
                          item === "すべて"
                            ? []
                            : toggleSelection(deckSocialDomains, item)
                        )
                      }
                    >
                      {item}
                    </button>
                  ))}
                </div>
              )}
              <div className="deck-filter-line">
                <div className="deck-grade-select multi-grade-filter">
                  <span>学年</span>
                  <button
                    className={deckGrades.length === 0 ? "selected" : ""}
                    type="button"
                    onClick={() => setDeckGrades([])}
                  >
                    すべて
                  </button>
                  {grades.map(value => (
                    <button
                      className={deckGrades.includes(value) ? "selected" : ""}
                      type="button"
                      key={value}
                      onClick={() =>
                        setDeckGrades(toggleSelection(deckGrades, value))
                      }
                    >
                      中{value}
                    </button>
                  ))}
                </div>
                <label className="deck-search-box">
                  <Search size={15} />
                  <input
                    value={deckSearch}
                    onChange={event => setDeckSearch(event.target.value)}
                    placeholder="語句・意味を検索"
                    aria-label="キーワードを検索"
                  />
                </label>
                <span className="deck-count">
                  {filteredDeckCards.length} /{" "}
                  {
                    deckCards.filter(
                      card => card.listId === activeKeywordListId
                    ).length
                  }{" "}
                  枚
                </span>
              </div>
            </div>

            {deckNotice && <p className="deck-notice">{deckNotice}</p>}

            {showDeckForm && (
              <form
                className="deck-create-form"
                onSubmit={event => {
                  event.preventDefault();
                  addDeckCard();
                }}
              >
                <div className="deck-form-title">
                  <span className="wood-dot" />
                  <strong>自分のキーワードを追加</strong>
                  <small className="form-multiline-hint">
                    Shift + Enterで改行
                  </small>
                </div>
                <label>
                  教科
                  <select
                    value={newDeckSubject}
                    onChange={event =>
                      setNewDeckSubject(event.target.value as SubjectKey)
                    }
                  >
                    {subjects.map(item => (
                      <option value={item.key} key={item.key}>
                        {item.key}
                      </option>
                    ))}
                  </select>
                </label>
                <div className="deck-form-multi-select">
                  学年
                  <div className="multi-select-options">
                    <button
                      className={newDeckGrades.length === 0 ? "selected" : ""}
                      type="button"
                      onClick={() => setNewDeckGrades([])}
                    >
                      すべて
                    </button>
                    {grades.map(value => (
                      <button
                        className={
                          newDeckGrades.includes(value) ? "selected" : ""
                        }
                        type="button"
                        key={value}
                        onClick={() =>
                          setNewDeckGrades(
                            toggleSelection(newDeckGrades, value)
                          )
                        }
                      >
                        中{value}
                      </button>
                    ))}
                  </div>
                </div>
                {newDeckSubject === "社会" && (
                  <div className="deck-form-multi-select">
                    分野
                    <div className="multi-select-options">
                      {socialKeywordDomains.slice(1).map(item => (
                        <button
                          className={
                            newDeckSocialDomains.includes(item)
                              ? "selected"
                              : ""
                          }
                          type="button"
                          onClick={() =>
                            setNewDeckSocialDomains(
                              toggleSelection(newDeckSocialDomains, item)
                            )
                          }
                          key={item}
                        >
                          {item}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
                <label className="deck-form-wide">
                  キーワード
                  <textarea
                    value={draftDeckTerm}
                    onChange={event => setDraftDeckTerm(event.target.value)}
                    placeholder="例：光合成"
                    autoFocus
                    rows={2}
                  />
                </label>
                <label className="deck-form-wide">
                  意味
                  <textarea
                    value={draftDeckMeaning}
                    onChange={event => setDraftDeckMeaning(event.target.value)}
                    placeholder="例：植物が光のエネルギーで養分をつくるはたらき"
                    rows={3}
                  />
                </label>
                <label className="deck-page-field">
                  教科書ページ
                  <input
                    type="number"
                    min="0"
                    step="1"
                    value={draftDeckPage}
                    onChange={event => setDraftDeckPage(event.target.value)}
                    placeholder="例：42"
                  />
                </label>
                <div className="deck-form-actions">
                  <button className="deck-save-button" type="submit">
                    <Plus size={15} /> 追加する
                  </button>
                  <button
                    className="deck-cancel-button"
                    type="button"
                    onClick={() => setShowDeckForm(false)}
                  >
                    <X size={14} /> 閉じる
                  </button>
                </div>
              </form>
            )}

            {filteredDeckCards.length > 0 ? (
              <div className="keyword-deck-grid">
                {filteredDeckCards.map(card => {
                  const cardSubject = getSubject(card.subject);
                  const isFlipped = Boolean(flippedDeckCards[card.id]);
                  const isEditing = editingDeckId === card.id;
                  return (
                    <article
                      className={`deck-card-shell ${card.custom ? "is-custom" : ""}`}
                      key={card.id}
                    >
                      {isEditing ? (
                        <div className="deck-inline-form">
                          <p className="deck-inline-label">カードを編集</p>
                          <input
                            value={draftDeckTerm}
                            onChange={event =>
                              setDraftDeckTerm(event.target.value)
                            }
                            aria-label="キーワード"
                          />
                          <label className="deck-sort-order-field">
                            並び順（小さい数字が先）
                            <input
                              type="number"
                              min="0"
                              step="1"
                              value={draftDeckSortOrder}
                              onChange={event =>
                                setDraftDeckSortOrder(event.target.value)
                              }
                              aria-label="カードの並び順"
                            />
                          </label>
                          <label className="deck-sort-order-field">
                            教科書ページ（小さい順）
                            <input
                              type="number"
                              min="0"
                              step="1"
                              value={draftDeckPage}
                              onChange={event =>
                                setDraftDeckPage(event.target.value)
                              }
                              aria-label="教科書ページ"
                            />
                          </label>
                          <textarea
                            value={draftDeckMeaning}
                            onChange={event =>
                              setDraftDeckMeaning(event.target.value)
                            }
                            aria-label="キーワードの意味"
                            rows={3}
                          />
                          <div className="deck-inline-actions">
                            <button
                              className="deck-save-button"
                              type="button"
                              onClick={() => saveDeckEdit(card.id)}
                            >
                              保存
                            </button>
                            <button
                              className="deck-cancel-button"
                              type="button"
                              onClick={cancelDeckEdit}
                            >
                              キャンセル
                            </button>
                          </div>
                        </div>
                      ) : (
                        <>
                          <button
                            className={`deck-flip-card ${isFlipped ? "is-flipped" : ""}`}
                            type="button"
                            aria-pressed={isFlipped}
                            onClick={() =>
                              setFlippedDeckCards(prev => ({
                                ...prev,
                                [card.id]: !prev[card.id],
                              }))
                            }
                          >
                            <span className="deck-flip-face deck-flip-front">
                              <span
                                className="deck-card-subject"
                                style={{
                                  color: subjectColors[cardSubject.color],
                                }}
                              >
                                {card.subject} /{" "}
                                {card.years.map(year => `中${year}`).join("・")}
                              </span>
                              <strong>{card.term}</strong>
                              <small>タップして意味を見る</small>
                            </span>
                            <span className="deck-flip-face deck-flip-back">
                              <span>意味</span>
                              <strong>{card.meaning}</strong>
                              <small>タップで表に戻る</small>
                            </span>
                          </button>
                          <div className="deck-card-footer">
                            <span title={card.domains.join(" / ")}>
                              {card.custom
                                ? "自分のカード"
                                : card.domains.join(" / ")}
                            </span>
                            <span className="deck-page-label">
                              {card.textbookPage === null
                                ? "ページ未入力"
                                : `教科書 p.${card.textbookPage}`}
                            </span>
                            <div>
                              <button
                                className="deck-icon-button"
                                type="button"
                                onClick={() => copyKeywordToList(card.id)}
                                aria-label={`${card.term}を別リストへコピー`}
                                title="別リストへコピー"
                              >
                                <Copy size={13} />
                              </button>
                              <button
                                className="deck-icon-button"
                                type="button"
                                onClick={() => beginDeckEdit(card)}
                                aria-label={`${card.term}を編集`}
                              >
                                <Pencil size={13} />
                              </button>
                              <button
                                className="deck-icon-button danger"
                                type="button"
                                onClick={() => deleteDeckCard(card.id)}
                                aria-label={`${card.term}を削除`}
                              >
                                <Trash2 size={13} />
                              </button>
                            </div>
                          </div>
                        </>
                      )}
                    </article>
                  );
                })}
              </div>
            ) : (
              <div className="deck-empty-state">
                <Search size={22} />
                <strong>キーワードが見つかりませんでした</strong>
                <span>教科・学年・検索語を変えてみてください。</span>
              </div>
            )}
          </section>
        )}

        {page === "flashcards" && (
          <section id="flashcard-mode" className="flashcard-section page-shell">
            <div className="flashcard-heading">
              <div>
                <p className="eyebrow">FLASHCARD PRACTICE</p>
                <h2>スラッシュカード練習</h2>
                <p>
                  まず問題を考えてから「答えをめくる」。確認したら次のカードへ進む、
                  練習専用モードです。
                </p>
              </div>
              <span className="flashcard-rule">考える → めくる → 次へ</span>
            </div>
            <div className="flashcard-toolbar">
              <label>
                キーワードリスト
                <select
                  value={activeKeywordListId}
                  onChange={event => {
                    setActiveKeywordListId(event.target.value);
                    setFlashIndex(0);
                    setFlashRevealed(false);
                  }}
                >
                  {keywordLists.map(list => (
                    <option value={list.id} key={list.id}>
                      {list.name}
                    </option>
                  ))}
                </select>
              </label>
              <label>
                教科
                <select
                  value={flashSubject}
                  onChange={event => {
                    setFlashSubject(event.target.value as SubjectFilter);
                    setFlashSocialDomains([]);
                  }}
                >
                  <option value="all">全教科</option>
                  {subjects.map(item => (
                    <option value={item.key} key={item.key}>
                      {item.key}
                    </option>
                  ))}
                </select>
              </label>
              <div className="multi-filter-group">
                学年
                <div className="multi-filter-options">
                  <button
                    className={flashGrades.length === 0 ? "selected" : ""}
                    type="button"
                    onClick={() => setFlashGrades([])}
                  >
                    すべて
                  </button>
                  {grades.map(value => (
                    <button
                      className={flashGrades.includes(value) ? "selected" : ""}
                      type="button"
                      key={value}
                      onClick={() =>
                        setFlashGrades(toggleSelection(flashGrades, value))
                      }
                    >
                      中{value}
                    </button>
                  ))}
                </div>
              </div>
              {flashSubject === "社会" && (
                <div className="multi-filter-group">
                  分野
                  <div className="multi-filter-options">
                    {socialKeywordDomains.map(item => (
                      <button
                        className={
                          flashSocialDomains.length === 0 ||
                          flashSocialDomains.includes(item)
                            ? "selected"
                            : ""
                        }
                        type="button"
                        key={item}
                        onClick={() =>
                          setFlashSocialDomains(
                            item === "すべて"
                              ? []
                              : toggleSelection(flashSocialDomains, item)
                          )
                        }
                      >
                        {item}
                      </button>
                    ))}
                  </div>
                </div>
              )}
              <span className="flashcard-total">全 {flashCards.length} 枚</span>
            </div>

            {currentFlashCard ? (
              <>
                <div className="flashcard-progress-row">
                  <span>
                    {flashIndex + 1} / {flashCards.length} 枚目
                  </span>
                  <div className="flashcard-progress-track">
                    <span
                      style={{
                        width: `${((flashIndex + 1) / flashCards.length) * 100}%`,
                      }}
                    />
                  </div>
                </div>
                <div
                  className={`study-flashcard ${flashRevealed ? "is-revealed" : ""}`}
                >
                  <div className="study-flashcard-front">
                    <span className="study-card-kicker">QUESTION</span>
                    <span
                      className="study-card-subject"
                      style={{
                        color:
                          subjectColors[
                            getSubject(currentFlashCard.subject).color
                          ],
                      }}
                    >
                      {currentFlashCard.subject} /{" "}
                      {currentFlashCard.domains.join("・")}
                    </span>
                    <h3>{currentFlashCard.term}</h3>
                    <p>このキーワードの意味を、自分の言葉で答えてみよう。</p>
                  </div>
                  <div className="study-flashcard-back">
                    <span className="study-card-kicker">ANSWER</span>
                    <h3>{currentFlashCard.term}</h3>
                    <p>{currentFlashCard.meaning}</p>
                    <small className="study-card-page">
                      {currentFlashCard.textbookPage === null
                        ? "教科書ページ未入力"
                        : `教科書 p.${currentFlashCard.textbookPage}`}
                    </small>
                  </div>
                </div>
                <div className="flashcard-action-row">
                  <button
                    className="flashcard-reveal-button"
                    type="button"
                    disabled={flashRevealed}
                    onClick={() => setFlashRevealed(true)}
                  >
                    {flashRevealed ? "答えを確認しました" : "答えをめくる"}
                  </button>
                  <button
                    className="flashcard-next-button"
                    type="button"
                    disabled={!flashRevealed}
                    onClick={() => {
                      setFlashIndex(index => (index + 1) % flashCards.length);
                      setFlashRevealed(false);
                    }}
                  >
                    次のカードへ <ArrowRight size={15} />
                  </button>
                </div>
                <p className="flashcard-helper">
                  {flashRevealed
                    ? "答えを確認したら、次のカードへ進めます。"
                    : "まず頭の中で答えてから、答えをめくりましょう。"}
                </p>
              </>
            ) : (
              <div className="flashcard-empty-state">
                <strong>この条件のカードはありません</strong>
                <span>教科や学年を変えてみてください。</span>
              </div>
            )}
          </section>
        )}

        {page === "practice" && (
          <section id="practice" className="practice-section page-shell">
            <div className="practice-heading">
              <div>
                <p className="eyebrow">PRACTICE ROOM</p>
                <h2>練習問題</h2>
                <p>
                  教科書に沿った確認問題を解いて、すぐに答えと解説を確認できます。
                  自分で作った問題も追加・編集できます。
                </p>
              </div>
              <div className="practice-heading-actions">
                <button
                  className="deck-add-button"
                  type="button"
                  onClick={() => {
                    setShowPracticeForm(open => !open);
                    cancelPracticeEdit();
                    setPracticeNotice("");
                  }}
                >
                  <Plus size={16} /> 自作問題を追加
                </button>
                <button
                  className="deck-reset-button"
                  type="button"
                  onClick={resetPracticeProblems}
                >
                  <RotateCcw size={14} /> 初期状態
                </button>
              </div>
            </div>

            <div className="study-list-manager">
              <label>
                練習問題リスト
                <select
                  value={activePracticeListId}
                  onChange={event => {
                    setActivePracticeListId(event.target.value);
                    setEditingPracticeId(null);
                    setPracticeAnswer(null);
                  }}
                >
                  {practiceLists.map(list => (
                    <option value={list.id} key={list.id}>
                      {list.name}
                    </option>
                  ))}
                </select>
              </label>
              <form
                className="study-list-create"
                onSubmit={event => {
                  event.preventDefault();
                  createPracticeList();
                }}
              >
                <input
                  value={newPracticeListName}
                  onChange={event => setNewPracticeListName(event.target.value)}
                  placeholder="新しいリスト名"
                  aria-label="新しい練習問題リスト名"
                />
                <button type="submit">
                  <Plus size={14} /> リストを作る
                </button>
              </form>
              <span className="study-list-count">
                {practiceLists.length}個のリスト
              </span>
            </div>

            <div className="practice-toolbar">
              <label>
                教科
                <select
                  value={practiceSubject}
                  onChange={event =>
                    setPracticeSubject(event.target.value as SubjectFilter)
                  }
                >
                  <option value="all">全教科</option>
                  {subjects.map(item => (
                    <option value={item.key} key={item.key}>
                      {item.key}
                    </option>
                  ))}
                </select>
              </label>
              <div className="multi-filter-group">
                学年
                <div className="multi-filter-options">
                  <button
                    className={practiceGrades.length === 0 ? "selected" : ""}
                    type="button"
                    onClick={() => setPracticeGrades([])}
                  >
                    すべて
                  </button>
                  {grades.map(value => (
                    <button
                      className={
                        practiceGrades.includes(value) ? "selected" : ""
                      }
                      type="button"
                      key={value}
                      onClick={() =>
                        setPracticeGrades(
                          toggleSelection(practiceGrades, value)
                        )
                      }
                    >
                      中{value}
                    </button>
                  ))}
                </div>
              </div>
              <label className="practice-search">
                <Search size={15} />
                <input
                  value={practiceSearch}
                  onChange={event => setPracticeSearch(event.target.value)}
                  placeholder="問題・答え・分野を検索"
                />
              </label>
              <span className="practice-count">
                {filteredPracticeProblems.length} /{" "}
                {
                  practiceProblems.filter(
                    problem => problem.listId === activePracticeListId
                  ).length
                }{" "}
                問
              </span>
            </div>

            {practiceNotice && (
              <p className="practice-notice">{practiceNotice}</p>
            )}

            {showPracticeForm && (
              <form
                className="practice-create-form"
                onSubmit={event => {
                  event.preventDefault();
                  editingPracticeId
                    ? savePracticeEdit(editingPracticeId)
                    : addPracticeProblem();
                }}
              >
                <div className="practice-form-title">
                  <span className="wood-dot" />
                  <strong>
                    {editingPracticeId ? "問題を編集" : "自分の問題を追加"}
                  </strong>
                  <small className="form-multiline-hint">
                    Shift + Enterで改行
                  </small>
                </div>
                <label>
                  問題形式
                  <select
                    value={draftPracticeFormat}
                    onChange={event =>
                      setDraftPracticeFormat(
                        event.target.value as "choice" | "written"
                      )
                    }
                  >
                    <option value="choice">選択問題</option>
                    <option value="written">文章問題</option>
                  </select>
                </label>
                {!editingPracticeId && (
                  <>
                    <label>
                      教科
                      <select
                        value={newPracticeSubject}
                        onChange={event =>
                          setNewPracticeSubject(
                            event.target.value as SubjectKey
                          )
                        }
                      >
                        {subjects.map(item => (
                          <option value={item.key} key={item.key}>
                            {item.key}
                          </option>
                        ))}
                      </select>
                    </label>
                    <label>
                      学年
                      <select
                        value={newPracticeGrade}
                        onChange={event =>
                          setNewPracticeGrade(
                            parseGradeFilter(event.target.value)
                          )
                        }
                      >
                        <option value="all">中学1〜3年</option>
                        {grades.map(value => (
                          <option value={value} key={value}>
                            中学{value}年
                          </option>
                        ))}
                      </select>
                    </label>
                  </>
                )}
                <label className="practice-wide-field">
                  問題文
                  <textarea
                    value={draftPracticeQuestion}
                    onChange={event =>
                      setDraftPracticeQuestion(event.target.value)
                    }
                    placeholder="例：光合成で植物が取り入れる気体はどれ？"
                    rows={2}
                  />
                </label>
                {draftPracticeFormat === "choice" ? (
                  <>
                    <div className="practice-choice-fields">
                      <span>選択肢（4つ）</span>
                      {draftPracticeChoices.map((choice, index) => (
                        <label key={index}>
                          {String.fromCharCode(65 + index)}
                          <input
                            value={choice}
                            onChange={event =>
                              setDraftPracticeChoices(prev =>
                                prev.map((item, itemIndex) =>
                                  itemIndex === index
                                    ? event.target.value
                                    : item
                                )
                              )
                            }
                            placeholder={`選択肢${index + 1}`}
                          />
                        </label>
                      ))}
                    </div>
                    <label>
                      正解
                      <select
                        value={draftPracticeAnswer}
                        onChange={event =>
                          setDraftPracticeAnswer(event.target.value)
                        }
                      >
                        {draftPracticeChoices.map((_, index) => (
                          <option value={index} key={index}>
                            {String.fromCharCode(65 + index)}
                          </option>
                        ))}
                      </select>
                    </label>
                  </>
                ) : (
                  <label className="practice-wide-field">
                    模範解答
                    <textarea
                      value={draftPracticeWrittenAnswer}
                      onChange={event =>
                        setDraftPracticeWrittenAnswer(event.target.value)
                      }
                      placeholder="例：植物は光エネルギーを使って、二酸化炭素と水から養分をつくる。"
                      rows={3}
                    />
                  </label>
                )}
                <label className="practice-wide-field">
                  解説
                  <textarea
                    value={draftPracticeExplanation}
                    onChange={event =>
                      setDraftPracticeExplanation(event.target.value)
                    }
                    placeholder="なぜその答えになるのかを書きましょう。"
                    rows={2}
                  />
                </label>
                <div className="practice-form-actions">
                  <button className="deck-save-button" type="submit">
                    <Check size={15} />{" "}
                    {editingPracticeId ? "保存" : "問題を追加"}
                  </button>
                  <button
                    className="deck-cancel-button"
                    type="button"
                    onClick={() => {
                      cancelPracticeEdit();
                      setShowPracticeForm(false);
                    }}
                  >
                    <X size={14} /> 閉じる
                  </button>
                </div>
              </form>
            )}

            {currentPracticeProblem ? (
              <>
                <div className="practice-progress-row">
                  <span>
                    {practiceIndex + 1} / {filteredPracticeProblems.length} 問目
                  </span>
                  <div className="practice-progress-track">
                    <span
                      style={{
                        width: `${((practiceIndex + 1) / filteredPracticeProblems.length) * 100}%`,
                      }}
                    />
                  </div>
                </div>
                <article className="practice-question-card">
                  <div className="practice-question-meta">
                    <span>{currentPracticeProblem.subject}</span>
                    <span>{currentPracticeProblem.domain}</span>
                    <span>
                      {currentPracticeProblem.years
                        .map(year => `中${year}`)
                        .join("・")}
                    </span>
                  </div>
                  <h3>{currentPracticeProblem.question}</h3>
                  {currentPracticeIsWritten ? (
                    <div className="practice-written-answer">
                      <label>
                        あなたの答え
                        <textarea
                          value={practiceWrittenResponse}
                          onChange={event => {
                            setPracticeWrittenResponse(event.target.value);
                            setPracticeAnswer(null);
                          }}
                          placeholder="自分の言葉で答えを書きましょう。"
                          rows={4}
                          disabled={practiceAnswer !== null}
                        />
                      </label>
                      <button
                        className="flashcard-reveal-button"
                        type="button"
                        disabled={
                          !practiceWrittenResponse.trim() ||
                          practiceAnswer !== null
                        }
                        onClick={() =>
                          setPracticeAnswer(practiceWrittenResponse)
                        }
                      >
                        答えを確認する
                      </button>
                    </div>
                  ) : (
                    <div className="practice-options">
                      {currentPracticeProblem.choices.map((choice, index) => (
                        <button
                          className={`practice-option ${
                            practiceAnswer === index ? "selected" : ""
                          } ${
                            practiceAnswer !== null &&
                            index === currentPracticeProblem.answer
                              ? "correct"
                              : ""
                          } ${
                            practiceAnswer !== null &&
                            practiceAnswer === index &&
                            index !== currentPracticeProblem.answer
                              ? "wrong"
                              : ""
                          }`}
                          key={choice}
                          type="button"
                          onClick={() => setPracticeAnswer(index)}
                        >
                          <span>{String.fromCharCode(65 + index)}</span>
                          {choice}
                        </button>
                      ))}
                    </div>
                  )}
                  {practiceAnswer !== null && (
                    <div
                      className={`practice-feedback ${
                        (
                          currentPracticeIsWritten
                            ? currentWrittenAnswerIsCorrect
                            : practiceAnswer === currentPracticeProblem.answer
                        )
                          ? "is-correct"
                          : "is-wrong"
                      }`}
                    >
                      <strong>
                        {(
                          currentPracticeIsWritten
                            ? currentWrittenAnswerIsCorrect
                            : practiceAnswer === currentPracticeProblem.answer
                        )
                          ? "正解です"
                          : currentPracticeIsWritten
                            ? `不正解。模範解答：${currentPracticeProblem.writtenAnswer}`
                            : `不正解。正解は ${String.fromCharCode(65 + currentPracticeProblem.answer)} です`}
                      </strong>
                      <p>{currentPracticeProblem.explanation}</p>
                    </div>
                  )}
                </article>
                <div className="practice-next-row">
                  <button
                    className="flashcard-next-button"
                    type="button"
                    disabled={practiceAnswer === null}
                    onClick={() => {
                      setPracticeIndex(
                        index => (index + 1) % filteredPracticeProblems.length
                      );
                      setPracticeAnswer(null);
                      setPracticeWrittenResponse("");
                    }}
                  >
                    次の問題へ <ArrowRight size={15} />
                  </button>
                </div>
              </>
            ) : (
              <div className="practice-empty-state">
                <Search size={22} />
                <strong>問題が見つかりませんでした</strong>
                <span>教科・学年・検索語を変えてみてください。</span>
              </div>
            )}

            <div className="practice-library-head">
              <div>
                <p className="eyebrow">MY PROBLEM LIBRARY</p>
                <h3>問題一覧</h3>
              </div>
              <span>鉛筆ボタンから問題文・選択肢・解説を編集できます</span>
            </div>
            <div className="practice-library-grid">
              {filteredPracticeProblems.map(problem => (
                <article
                  className={`practice-library-card ${problem.custom ? "is-custom" : ""}`}
                  key={problem.id}
                >
                  <div className="practice-library-top">
                    <span>
                      {problem.subject} / {problem.domain}
                    </span>
                    {problem.custom && <small>自作</small>}
                  </div>
                  <strong>{problem.question}</strong>
                  <div className="practice-library-actions">
                    <button
                      className="deck-icon-button"
                      type="button"
                      onClick={() => beginPracticeEdit(problem)}
                      aria-label="問題を編集"
                    >
                      <Pencil size={13} /> 編集
                    </button>
                    <button
                      className="deck-icon-button danger"
                      type="button"
                      onClick={() => deletePracticeProblem(problem.id)}
                      aria-label="問題を削除"
                    >
                      <Trash2 size={13} /> 削除
                    </button>
                  </div>
                </article>
              ))}
            </div>
          </section>
        )}

        {page === "lesson" && (
          <section id="lesson" className="lesson-zone page-shell">
            <div className="lesson-header">
              <div>
                <p className="eyebrow">
                  LESSON NOTE / {currentUnit.subject} ·{" "}
                  {gradeLabel(currentUnit)}
                </p>
                <h2>授業ノート</h2>
              </div>
              <button
                className="ai-open-button"
                type="button"
                onClick={() => setAiOpen(true)}
              >
                <Sparkles size={16} /> AI先生に聞く
              </button>
            </div>
            <div className="lesson-layout">
              <article className="lesson-paper">
                <div className="lesson-paper-head">
                  <div>
                    <span
                      className="lesson-subject-label"
                      style={{ color: subjectColors[currentSubject.color] }}
                    >
                      {currentUnit.subject} / {currentUnit.domain}
                    </span>
                    <h3>{currentUnit.title}</h3>
                    <p>{currentUnit.summary}</p>
                  </div>
                  <span className="lesson-chapter">{currentUnit.eyebrow}</span>
                </div>
                <div className="lesson-body">
                  <div className="lesson-block">
                    <div className="block-title">
                      <span className="number-badge">01</span>
                      <h4>要点をつかむ</h4>
                    </div>
                    <ul>
                      {currentUnit.points.map(point => (
                        <li key={point}>
                          <Check size={14} />
                          {point}
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div className="lesson-block">
                    <div className="block-title">
                      <span className="number-badge mustard">02</span>
                      <div>
                        <h4>重要語句 / スラッシュカード</h4>
                        <p className="block-caption">
                          教科書の太字キーワードをタップして意味を確認
                        </p>
                      </div>
                    </div>
                    <div className="keyword-flashcards">
                      {currentUnit.keywordCards.map(card => {
                        const isFlipped = Boolean(flippedKeywords[card.term]);
                        return (
                          <button
                            key={card.term}
                            className={`keyword-card ${isFlipped ? "is-flipped" : ""}`}
                            type="button"
                            aria-pressed={isFlipped}
                            onClick={() =>
                              setFlippedKeywords(prev => ({
                                ...prev,
                                [card.term]: !prev[card.term],
                              }))
                            }
                          >
                            <span className="keyword-card-face keyword-card-front">
                              <strong>{card.term}</strong>
                              <small>意味を見る</small>
                            </span>
                            <span className="keyword-card-face keyword-card-back">
                              <small>意味</small>
                              <strong>{card.meaning}</strong>
                              <span>タップで戻る</span>
                            </span>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                  <div className="lesson-block example-block">
                    <div className="block-title">
                      <span className="number-badge coral">03</span>
                      <h4>例題で考える</h4>
                    </div>
                    <p>{currentUnit.example}</p>
                  </div>
                  <div className="quiz-block">
                    <div className="block-title">
                      <span className="number-badge purple">04</span>
                      <h4>確認問題</h4>
                      <span className="quiz-hint">
                        <CircleHelp size={14} /> 1問
                      </span>
                    </div>
                    <p className="quiz-question">{currentUnit.quiz.question}</p>
                    <div className="quiz-options">
                      {currentUnit.quiz.choices.map((choice, index) => (
                        <button
                          key={choice}
                          className={`${quizAnswer === index ? "answered" : ""} ${quizAnswer !== null && index === currentUnit.quiz.answer ? "correct" : ""}`}
                          onClick={() => setQuizAnswer(index)}
                          type="button"
                        >
                          <span>{String.fromCharCode(65 + index)}</span>
                          {choice}
                          {quizAnswer !== null &&
                            index === currentUnit.quiz.answer && (
                              <Check size={15} />
                            )}
                        </button>
                      ))}
                    </div>
                    {quizAnswer !== null && (
                      <p
                        className={`quiz-feedback ${quizAnswer === currentUnit.quiz.answer ? "is-correct" : "is-wrong"}`}
                      >
                        {quizAnswer === currentUnit.quiz.answer
                          ? "正解！ "
                          : "おしい！ "}
                        {currentUnit.quiz.explanation}
                      </p>
                    )}
                  </div>
                </div>
                <div className="lesson-paper-footer">
                  <span>
                    <Clock3 size={14} /> 目安 15分
                  </span>
                  <button type="button" onClick={() => setAiOpen(true)}>
                    わからないところを質問 <MessageCircle size={14} />
                  </button>
                </div>
              </article>
              <aside className="lesson-aside">
                <div className="aside-note">
                  <span className="pin pin-yellow" />
                  <p className="eyebrow">MEMO</p>
                  <h3>
                    ノートの余白に
                    <br />
                    自分の言葉で。
                  </h3>
                  <p>
                    授業のあとに「今日わかったこと」を一行だけ書くと、記憶に残りやすくなります。
                  </p>
                </div>
                <div className="next-unit">
                  <span>次におすすめ</span>
                  <button
                    type="button"
                    onClick={() =>
                      selectUnit(
                        allUnits[
                          (allUnits.findIndex(
                            unit => unit.id === currentUnit.id
                          ) +
                            1) %
                            allUnits.length
                        ]
                      )
                    }
                  >
                    <strong>もう一つの授業へ</strong>
                    <ArrowRight size={15} />
                  </button>
                </div>
              </aside>
            </div>
          </section>
        )}
      </main>

      <button
        className={`ai-float ${aiOpen ? "is-hidden" : ""}`}
        type="button"
        onClick={() => setAiOpen(true)}
      >
        <span className="ai-orb">
          <Sparkles size={19} />
        </span>
        <span>
          <strong>AI先生</strong>
          <small>質問してみよう</small>
        </span>
      </button>
      {aiOpen && (
        <div className="ai-overlay" onClick={() => setAiOpen(false)} />
      )}
      <aside
        className={`ai-drawer ${aiOpen ? "is-open" : ""}`}
        aria-label="AI先生"
      >
        <div className="ai-drawer-head">
          <div className="ai-avatar">
            <Sparkles size={20} />
          </div>
          <div>
            <p className="eyebrow">YOUR STUDY PARTNER</p>
            <h2>AI先生</h2>
            <span>いまは「{currentUnit.title}」の授業中</span>
          </div>
          <button
            type="button"
            onClick={() => setAiOpen(false)}
            aria-label="AI先生を閉じる"
          >
            <X size={19} />
          </button>
        </div>
        <div className="ai-context">
          <span style={{ background: subjectColors[currentSubject.color] }} />
          {currentUnit.subject} / {gradeLabel(currentUnit)} /{" "}
          {currentUnit.domain}
        </div>
        <div className="ai-messages">
          {messages.map((message, index) => (
            <div
              key={`${message.role}-${index}`}
              className={`ai-message ${message.role}`}
            >
              <span className="message-icon">
                {message.role === "assistant" ? (
                  <Sparkles size={13} />
                ) : (
                  <NotebookPen size={13} />
                )}
              </span>
              <div>{message.content}</div>
            </div>
          ))}
          {aiLoading && (
            <div className="ai-message assistant">
              <span className="message-icon">
                <Sparkles size={13} />
              </span>
              <div className="typing">
                <i />
                <i />
                <i />
              </div>
            </div>
          )}
        </div>
        <div className="ai-suggestions">
          <button
            type="button"
            onClick={() => sendQuestion("もっとかんたんに説明して")}
          >
            もっとかんたんに
          </button>
          <button
            type="button"
            onClick={() => sendQuestion("身近な例を出して")}
          >
            例を出して
          </button>
          <button
            type="button"
            onClick={() => sendQuestion("テストに出そうなポイントは？")}
          >
            テスト対策
          </button>
        </div>
        {aiError && <p className="ai-error">{aiError}</p>}
        <form
          className="ai-compose"
          onSubmit={event => {
            event.preventDefault();
            void sendQuestion();
          }}
        >
          <textarea
            value={draft}
            onChange={event => setDraft(event.target.value)}
            placeholder="授業について質問してみよう…"
            rows={2}
          />
          <button
            type="submit"
            disabled={aiLoading || !draft.trim()}
            aria-label="質問を送る"
          >
            <Send size={17} />
          </button>
        </form>
        <p className="ai-disclaimer">
          AI先生の説明は学習のヒントです。教科書や先生の説明も一緒に確認しよう。
        </p>
      </aside>

      <footer className="site-footer">
        <div className="page-shell">
          <div className="footer-brand">
            <BookMark color="#F1EADB" />
            <strong>まなび教室</strong>
          </div>
          <span>教科書に沿って、今日の一問まで。</span>
          <span>中学生のための学習室</span>
        </div>
      </footer>
    </div>
  );
}
