import "dotenv/config";
import express from "express";
import { createServer } from "http";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerOAuthRoutes } from "./oauth";
import { publicPlatformScript } from "./publicConfig";
import { appRouter } from "../routers";
import { createContext } from "./context";
import { invokeLLM, type Message } from "./llm";
import { serveStatic, setupVite } from "./vite";

const clampText = (value: unknown, maxLength: number) =>
  typeof value === "string" ? value.trim().slice(0, maxLength) : "";

async function startServer() {
  const app = express();
  const server = createServer(app);
  // Configure body parser with larger size limit for file uploads
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));
  app.get("/api/health", (_req, res) => res.json({ status: "ok" }));
  app.get("/api/platform/config.js", (_req, res) => {
    res
      .set("Cache-Control", "no-store")
      .type("application/javascript")
      .send(publicPlatformScript());
  });

  app.post("/api/ai/chat", async (req, res) => {
    const body = req.body as {
      context?: Record<string, unknown>;
      messages?: Array<{ role?: string; content?: unknown }>;
    };
    const context = body.context ?? {};
    const incomingMessages = Array.isArray(body.messages) ? body.messages : [];
    const messages: Message[] = incomingMessages
      .slice(-10)
      .map(message => ({
        role:
          message.role === "assistant"
            ? ("assistant" as const)
            : ("user" as const),
        content: clampText(message.content, 1200),
      }))
      .filter(message => message.content.length > 0);

    const subject = clampText(context.subject, 30);
    const grade = clampText(context.grade, 20);
    const domain = clampText(context.domain, 30);
    const unit = clampText(context.unit, 80);
    const summary = clampText(context.summary, 500);
    const points = Array.isArray(context.points)
      ? context.points
          .map(point => clampText(point, 120))
          .filter(Boolean)
          .join(" / ")
      : "";
    const terms = Array.isArray(context.terms)
      ? context.terms
          .map(term => clampText(term, 40))
          .filter(Boolean)
          .join("、")
      : "";

    if (!messages.length) {
      res.status(400).json({ error: "質問を入力してください。" });
      return;
    }

    try {
      const result = await invokeLLM({
        messages: [
          {
            role: "system",
            content: `あなたは中学生の隣の席にいる日本語のAI先生です。答えを急いで教えるのではなく、考え方をやさしく説明してください。現在の授業は「${subject}・${grade}・${domain}・${unit}」です。授業の要点は${summary}。重要語句は${terms}。確認できるポイントは${points}。回答は日本語で、200〜350字程度。必要なら短い例や一問を添えてください。危険な内容、個人情報、成績の断定には対応せず、学校の先生や保護者への相談を促してください。`,
          },
          ...messages,
        ],
        maxTokens: 450,
      });
      const content = result.choices?.[0]?.message?.content;
      const text = typeof content === "string" ? content.trim() : "";
      if (!text) throw new Error("AI先生から回答を受け取れませんでした。");
      res.json({ content: text });
    } catch (error) {
      console.error("[AI Teacher] Request failed:", error);
      res
        .status(502)
        .json({
          error:
            "AI先生が一時的に休憩中です。少し時間をおいて、もう一度質問してみてください。",
        });
    }
  });

  registerOAuthRoutes(app);
  // tRPC API
  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext,
    })
  );
  // development mode uses Vite, production mode uses static files
  if (process.env.NODE_ENV === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  const port = Number(process.env.PORT || "3000");
  if (!Number.isInteger(port) || port < 1 || port > 65535)
    throw new Error("Invalid PORT");
  server.on("error", error => {
    console.error("Server failed:", error.message);
    process.exit(1);
  });
  server.listen(port, "0.0.0.0", () =>
    console.log(`Server listening on port ${port}`)
  );
}

startServer().catch(error => {
  console.error(error);
  process.exit(1);
});
