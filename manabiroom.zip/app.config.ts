export default {
  logoUrl: "https://dummyimage.com/256x256/174f4b/f1eadb.png&text=M",
};
